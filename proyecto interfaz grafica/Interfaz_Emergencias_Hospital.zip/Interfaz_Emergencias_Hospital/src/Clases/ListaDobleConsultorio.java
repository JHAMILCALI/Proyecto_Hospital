package Clases;
//Lic Aruquipa Marcelo
public class ListaDobleConsultorio {
	protected NodoConsultorio P;
	
	ListaDobleConsultorio(){
		this.P = null;
	}

	public NodoConsultorio getP() {
		return P;
	}

	public void setP(NodoConsultorio p) {
		P = p;
	}
	
}
