package Clases;
//Lic Aruquipa Marcelo
public class ListaDobleDoctor {
	protected NodoDoctor P;
	
	ListaDobleDoctor(){
		this.P = null;
	}

	public NodoDoctor getP() {
		return P;
	}

	public void setP(NodoDoctor p) {
		P = p;
	}
	
}
