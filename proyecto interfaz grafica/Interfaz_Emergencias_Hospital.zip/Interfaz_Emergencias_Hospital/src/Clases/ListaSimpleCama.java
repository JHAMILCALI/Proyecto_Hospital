package Clases;

public class ListaSimpleCama {
	protected
	NodoCama p;
	public
	ListaSimpleCama() {
		p=null;
	}
	public NodoCama getP() {
		return p;
	}
	public void setP(NodoCama p) {
		this.p = p;
	}
}
