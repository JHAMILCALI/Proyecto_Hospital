package Clases;
public class ColaEnfermera extends VectorEnfermera{
	protected int fr;
	protected int fi;
	
	public ColaEnfermera() {
		this.fr = 0;
		this.fi = 0;
	}
}
