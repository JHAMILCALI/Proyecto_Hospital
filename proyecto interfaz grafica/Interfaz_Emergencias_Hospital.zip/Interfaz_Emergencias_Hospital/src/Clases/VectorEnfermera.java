package Clases;
public class VectorEnfermera {
	protected int MAX = 50;
	//por la relacion de composicion se define el vector de objetos estudiante
	protected Enfermera [] v = new Enfermera[MAX]; 
}
