package Clases;
//Lic Aruquipa Marcelo
public class ListaDoblePaciente {
	protected NodoPaciente P;
	
	ListaDoblePaciente(){
		this.P = null;
	}

	public NodoPaciente getP() {
		return P;
	}

	public void setP(NodoPaciente p) {
		P = p;
	}
	
}
