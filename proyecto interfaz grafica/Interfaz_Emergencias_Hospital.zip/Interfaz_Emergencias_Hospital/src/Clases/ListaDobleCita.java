package Clases;
//Lic Aruquipa Marcelo
public class ListaDobleCita{
	protected NodoCita P;
	
	ListaDobleCita(){
		this.P = null;
	}

	public NodoCita getP() {
		return P;
	}

	public void setP(NodoCita p) {
		P = p;
	}
	
}
